<?php
/**
 * Cookie / session based Open edX *program* enrollment client.
 *
 * Mirrors the course enrollment client (enrollment-api.php): it reuses the
 * logged-in user's own Open edX session cookies (forwarded verbatim) plus a
 * fresh CSRF token to call the RWAQ programs enrollment API on the learner's
 * behalf. The endpoint is a single REST resource whose HTTP verb selects the
 * operation:
 *
 *   GET    /rwaq/api/programs/my/enrollment/{program_key}/   → status
 *   POST   /rwaq/api/programs/my/enrollment/{program_key}/   → enroll
 *   DELETE /rwaq/api/programs/my/enrollment/{program_key}/   → unenroll
 *
 * The generic cookie / CSRF helpers (enroll_collect_cookies(),
 * enroll_serialize_cookies(), enroll_get_csrf_token(), enroll_has_edx_session(),
 * enroll_build_cookie_header(), enroll_lms_base_url()) are NOT course-specific
 * and are shared from enrollment-api.php, which is always loaded first.
 *
 * @package tutor-sso
 */

namespace TutorSSO;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Program enrollment endpoint path (appended to the LMS base URL, before the
 * program key and a trailing slash).
 */
const PROGRAM_ENROLLMENT_ENDPOINT = '/rwaq/api/programs/my/enrollment/';

/**
 * Build the enrollment API URL for a program key.
 *
 * Program keys are opaque edX-style keys (they contain "+" and ":") used
 * literally in the path — like programs_fetch_detail(), we do NOT url-encode
 * them. A trailing slash is required by the API.
 *
 * @param string $program_key Program key (program-v1:Org+Program+Run).
 * @return string
 */
function program_enrollment_url( $program_key ) {
	return enroll_lms_base_url() . PROGRAM_ENROLLMENT_ENDPOINT . trim( (string) $program_key ) . '/';
}

/**
 * Perform an enroll / unenroll action against the program enrollment API.
 *
 * enroll → POST, unenroll → DELETE, against the same resource URL. Reuses the
 * shared cookie-forwarding + CSRF flow so the LMS sees the same authenticated
 * session the user has in their browser (see enrollment-api.php).
 *
 * @param string $program_key Program key (program-v1:Org+Program+Run).
 * @param string $action      'enroll' or 'unenroll'.
 * @return array|\WP_Error { success: bool, status: int, body: string } or WP_Error.
 */
function program_change_enrollment( $program_key, $action ) {
	$base = enroll_lms_base_url();

	if ( empty( $base ) ) {
		return new \WP_Error( 'tutor_sso_no_base', __( 'LMS Base URL is not configured.', 'tutor-sso' ) );
	}

	if ( ! enroll_has_edx_session() ) {
		return new \WP_Error( 'tutor_sso_no_session', __( 'No active LMS session was found. Please log in to the LMS and try again.', 'tutor-sso' ) );
	}

	$action = in_array( $action, array( 'enroll', 'unenroll' ), true ) ? $action : 'enroll';
	$method = ( 'enroll' === $action ) ? 'POST' : 'DELETE';

	$cookies      = enroll_collect_cookies();
	$cookie_token = isset( $cookies['csrftoken'] ) ? $cookies['csrftoken'] : '';
	$csrf         = enroll_get_csrf_token( enroll_serialize_cookies( $cookies ), $cookie_token );

	if ( is_wp_error( $csrf ) ) {
		return $csrf;
	}

	// Force the outgoing csrftoken cookie to match the header token so Django's
	// double-submit CSRF check always passes.
	$cookies['csrftoken'] = $csrf;
	$cookie_header        = enroll_serialize_cookies( $cookies );

	$response = wp_remote_request(
		program_enrollment_url( $program_key ),
		array(
			'method'    => $method,
			'timeout'   => 30,
			'sslverify' => apply_filters( 'tutor_sso_ssl_verify', true ),
			'headers'   => array(
				'Accept'           => 'application/json, text/plain, */*',
				'Origin'           => $base,
				'Referer'          => $base . '/',
				'X-CSRFToken'      => $csrf,
				'X-Requested-With' => 'XMLHttpRequest',
				'Cookie'           => $cookie_header,
				'use-jwt-cookie'   => 'true',
			),
		)
	);

	if ( is_wp_error( $response ) ) {
		return $response;
	}

	$status = (int) wp_remote_retrieve_response_code( $response );
	$body   = wp_remote_retrieve_body( $response );

	// Log the LMS response on failure to aid diagnosis (only when WP_DEBUG).
	if ( ( $status < 200 || $status >= 300 ) && defined( 'WP_DEBUG' ) && WP_DEBUG ) {
		error_log( // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
			sprintf(
				'[tutor-sso] program %s for %s -> HTTP %d: %s',
				$action,
				$program_key,
				$status,
				wp_strip_all_tags( (string) $body )
			)
		);
	}

	return array(
		'success' => $status >= 200 && $status < 300,
		'status'  => $status,
		'body'    => $body,
	);
}

/**
 * The current user's state for a program, as the LMS reports it.
 *
 * `has_paid_access` is true when the learner may join with no checks: they paid
 * for this program or a live subscription covers it. It stays true
 * after they unenroll — so a buyer can re-enroll without paying again.
 *
 * @param string $program_key Program key.
 * @return array{enrolled:bool,has_paid_access:bool,subscription_ends_at:string}|\WP_Error
 */
function program_enroll_status( $program_key ) {
	$none = array(
		'enrolled'             => false,
		'has_paid_access'      => false,
		'subscription_ends_at' => '',
	);

	$base = enroll_lms_base_url();

	if ( empty( $base ) ) {
		return new \WP_Error( 'tutor_sso_no_base', __( 'LMS Base URL is not configured.', 'tutor-sso' ) );
	}

	if ( ! enroll_has_edx_session() ) {
		return $none;
	}

	$response = wp_remote_get(
		program_enrollment_url( $program_key ),
		array(
			'timeout'   => 20,
			'sslverify' => apply_filters( 'tutor_sso_ssl_verify', true ),
			'headers'   => array(
				'Accept'         => 'application/json, text/plain, */*',
				'Referer'        => $base . '/',
				'Cookie'         => enroll_build_cookie_header(),
				'use-jwt-cookie' => 'true',
			),
		)
	);

	if ( is_wp_error( $response ) ) {
		return $response;
	}

	$status = (int) wp_remote_retrieve_response_code( $response );

	// No enrollment record for this user/program.
	if ( 404 === $status ) {
		return $none;
	}

	$body = json_decode( wp_remote_retrieve_body( $response ), true );

	if ( $status < 200 || $status >= 300 || ! is_array( $body ) ) {
		return new \WP_Error(
			'tutor_sso_status_failed',
			__( 'Could not determine enrollment status from the LMS.', 'tutor-sso' )
		);
	}

	// { program_key, is_active, enrollment_date, completion_date, has_paid_access }
	return array(
		'enrolled'              => ! empty( $body['is_active'] ),
		// has_paid_access replaces has_order: true when the learner bought this,
		// and now also while a subscription covering it is live. has_order is
		// read as a fallback so the plugin works either side of the LMS release
		// that removes it — the spec allows no transition period, and without
		// this a deploy in the wrong order would make every buyer look unpaid.
		'has_paid_access'       => ! empty( $body['has_paid_access'] ) || ! empty( $body['has_order'] ),
		// For display only; decisions are made on has_paid_access alone.
		'subscription_ends_at'  => isset( $body['subscription_ends_at'] ) ? (string) $body['subscription_ends_at'] : '',
	);
}

/**
 * Whether the current user is actively enrolled in a program.
 *
 * @param string $program_key Program key.
 * @return bool|\WP_Error
 */
function program_is_enrolled( $program_key ) {
	$status = program_enroll_status( $program_key );

	return is_wp_error( $status ) ? $status : $status['enrolled'];
}
