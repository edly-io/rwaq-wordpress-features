<?php
/**
 * Public Courses API client + catalog data layer.
 *
 * Thin wrapper around the LMS public course catalog endpoints:
 *
 *   GET /api/v1/courses/          — paginated, searchable, org/category-filterable list
 *   GET /api/v1/courses/filters/  — available filter options (organizations,
 *                                   categories)
 *
 * The endpoint is public (no authentication / cookies required), so like the
 * programs client (see includes/programs/programs-client.php) we do not forward
 * any edX session cookies. Responses are short-lived-cached in a transient to
 * keep catalog pages fast and avoid hammering the LMS.
 *
 * List response shape (DRF PageNumberPagination):
 *   {
 *     "count": int, "next": url|null, "previous": url|null,
 *     "results": [ { course_key, slug, title, start, end, course_image, description,
 *                    org, org_logo, org_arabic_name, status, pricing, language,
 *                    effort, instructor, instructor_image, overview, ... }, ... ]
 *   }
 *
 * Supported list query args (verified against the stage API):
 *   page=<n> & page_size=<n>   pagination
 *   search=<term>              free-text search
 *   org=<A>,<B>                organization short names, comma-joined = OR
 *                              (names/short names only — ids are not matched)
 *   category=<A>,<B>           category names, comma-joined = OR (names only)
 *   ordering=title|-title      alphabetical sort
 *
 * Ordering is title-only by design of the endpoint: its OPTIONS metadata states
 * `?ordering=title | -title   default: title (ascending)`, and DRF's
 * OrderingFilter drops any other field silently (verified — `start`, `created`
 * and `id` all return the default order). The catalog therefore offers only the
 * two title sorts; see courses_allowed_ordering() for the date mapping kept in
 * reserve.
 *
 * courses_fetch() maps the raw API rows onto the flat card shape the catalog and
 * AJAX handler consume — only what the card actually renders:
 *   {
 *     id, key, slug, title, image, url,
 *     org_slug, org_name, instructor, start_text
 *   }
 *
 * `url` points at the local `course` post detail page ({site}/course/{slug}/),
 * built from the API slug — see course_detail_url().
 *
 * Organization shape (filter options, from the filters endpoint):
 *   { slug, name, logo, count }
 *
 * Category shape (filter options, from the filters endpoint):
 *   { slug, name, count }, where `slug` is the category name the list
 *   endpoint's `category` param matches (it also matches the Arabic name, but
 *   the English one is sent as the stable identifier).
 *
 * Internal organizations (name/short name starting with "test" — see
 * sso_hidden_org_prefixes()) are hidden from both the filter list and the
 * results. The API has no "exclude" filter, so the `org` param is sent as an
 * allowlist of the visible organizations, which keeps `count` and pagination
 * consistent with what is rendered.
 *
 * @package tutor-sso
 */

namespace TutorSSO;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Public courses list endpoint path (appended to the LMS base URL).
 */
const COURSES_PUBLIC_ENDPOINT = '/api/v1/courses/';

/**
 * Default cache lifetime, in seconds, for a fetched catalog page / org list.
 */
const COURSES_CACHE_TTL = 300; // 5 minutes.

/**
 * Catalog filters endpoint path (appended to the LMS base URL).
 */
const COURSES_FILTERS_ENDPOINT = '/api/v1/courses/filters/';

/**
 * Transient key for a courses API response, aligned to a shared TTL boundary so
 * the list and filters caches always expire together (see sso_cache_key()).
 *
 * @param string $prefix Key prefix identifying the resource.
 * @param string $url    Request URL.
 * @return string
 */
function courses_cache_key( $prefix, $url ) {
	return sso_cache_key( $prefix, $url, (int) apply_filters( 'tutor_sso_courses_cache_ttl', COURSES_CACHE_TTL ) );
}

/**
 * Resolve the configured LMS base URL (reuses the SSO setting).
 *
 * @return string Base URL without a trailing slash, or '' when unset.
 */
function courses_lms_base_url() {
	return rtrim( (string) sso_option( 'lms_base_url' ), '/' );
}

/**
 * Whitelisted `ordering` values. Maps a friendly sort key to the DRF ordering
 * expression sent to the API, so arbitrary field ordering cannot be injected
 * from the query string / AJAX.
 *
 * Only `title` / `-title` are honored by the API today; the date expressions are
 * forward-compatible (see the file header).
 *
 * @return array<string,string>
 */
function courses_allowed_ordering() {
	return array(
		'title_asc'  => 'title',  // أ–ي
		'title_desc' => '-title', // ي–أ
		// Not offered in the sort dropdown yet: the API's OrderingFilter drops
		// unknown fields silently, so these are no-ops until `start` is added to
		// its ordering_fields. Kept so the wiring is ready — re-add the labels in
		// courses_sort_options() once the endpoint supports them.
		'newest'     => '-start', // الأحدث أولًا
		'oldest'     => 'start',  // الأقدم أولًا
	);
}

/**
 * Normalize a requested ordering key into a DRF ordering expression.
 *
 * @param string $ordering Friendly key (e.g. "title_asc") or raw expression.
 * @return string DRF ordering expression, or '' when unrecognized.
 */
function courses_normalize_ordering( $ordering ) {
	$ordering = trim( (string) $ordering );

	if ( '' === $ordering ) {
		return '';
	}

	$allowed = courses_allowed_ordering();

	if ( isset( $allowed[ $ordering ] ) ) {
		return $allowed[ $ordering ];
	}

	// Also accept a raw expression if it's one of the mapped targets.
	return in_array( $ordering, $allowed, true ) ? $ordering : '';
}

/**
 * Serialize a query args map into a query string. Array values are joined into a
 * single comma-separated param (org=A,B) — the format the catalog API expects
 * for multi-select filters (repeated keys only honor the last value). Each value
 * is URL-encoded; the joining commas are left literal.
 *
 * @param array<string,mixed> $args Query args (scalars or arrays of scalars).
 * @return string Query string without a leading "?".
 */
function courses_build_query( $args ) {
	$parts = array();

	foreach ( $args as $key => $value ) {
		if ( is_array( $value ) ) {
			$items = array();
			foreach ( $value as $item ) {
				$item = trim( (string) $item );
				if ( '' !== $item ) {
					$items[] = rawurlencode( $item );
				}
			}
			if ( ! empty( $items ) ) {
				$parts[] = rawurlencode( $key ) . '=' . implode( ',', $items );
			}
			continue;
		}

		$value = trim( (string) $value );
		if ( '' !== $value ) {
			$parts[] = rawurlencode( $key ) . '=' . rawurlencode( $value );
		}
	}

	return implode( '&', $parts );
}

/**
 * GET a URL on the LMS public API and decode the JSON body.
 *
 * @param string $url       Absolute request URL.
 * @param string $cache_key Transient key for the decoded body.
 * @return array|\WP_Error Decoded body, or WP_Error on failure.
 */
function courses_request( $url, $cache_key ) {
	$cached = get_transient( $cache_key );

	if ( false !== $cached ) {
		return $cached;
	}

	$response = wp_remote_get(
		$url,
		array(
			'timeout'   => 20,
			'sslverify' => apply_filters( 'tutor_sso_ssl_verify', true ),
			'headers'   => array(
				'Accept' => 'application/json',
			),
		)
	);

	if ( is_wp_error( $response ) ) {
		return $response;
	}

	$status = (int) wp_remote_retrieve_response_code( $response );

	// DRF returns 404 ("Invalid page.") for a page past the last one. Treat that
	// as an empty result set rather than a hard error so the UI degrades
	// gracefully (e.g. a stale page number left in a request).
	if ( 404 === $status ) {
		return array(
			'count'    => 0,
			'next'     => null,
			'previous' => null,
			'results'  => array(),
		);
	}

	$body = json_decode( wp_remote_retrieve_body( $response ), true );

	if ( $status < 200 || $status >= 300 || ! is_array( $body ) ) {
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			error_log( // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
				sprintf( '[tutor-sso] courses list %s -> HTTP %d', $url, $status )
			);
		}

		return new \WP_Error(
			'tutor_sso_courses_failed',
			__( 'Could not load courses from the LMS.', 'tutor-sso' )
		);
	}

	set_transient( $cache_key, $body, apply_filters( 'tutor_sso_courses_cache_ttl', COURSES_CACHE_TTL ) );

	return $body;
}

/**
 * Fetch one page of courses from the LMS public catalog API (raw rows).
 *
 * @param int   $page     1-based page number.
 * @param int   $per_page Courses per page (sent as the `page_size` query arg).
 * @param array $args     Optional {
 *     @type string   $search   Free-text search term.
 *     @type string   $ordering Ordering key (see courses_allowed_ordering()).
 *     @type string[] $org      Organization codes to filter by (OR).
 *     @type string[] $category Category names to filter by (OR).
 *     @type string[] $pricing  'free' | 'paid' | 'program_only', OR'd.
 * }
 * @return array|\WP_Error { count, next, previous, results } or WP_Error.
 */
function courses_fetch_public( $page = 1, $per_page = 8, $args = array() ) {
	$base = courses_lms_base_url();

	if ( '' === $base ) {
		return new \WP_Error( 'tutor_sso_no_base', __( 'LMS Base URL is not configured.', 'tutor-sso' ) );
	}

	$query = array(
		'page'      => max( 1, (int) $page ),
		'page_size' => max( 1, (int) $per_page ),
	);

	if ( isset( $args['search'] ) && '' !== trim( (string) $args['search'] ) ) {
		$query['search'] = trim( (string) $args['search'] );
	}

	$ordering = isset( $args['ordering'] ) ? courses_normalize_ordering( $args['ordering'] ) : '';
	if ( '' !== $ordering ) {
		$query['ordering'] = $ordering;
	}

	if ( ! empty( $args['org'] ) ) {
		$query['org'] = (array) $args['org'];
	}

	if ( ! empty( $args['category'] ) ) {
		$query['category'] = (array) $args['category'];
	}

	if ( ! empty( $args['pricing'] ) ) {
		$query['pricing'] = (array) $args['pricing'];
	}

	$url = $base . COURSES_PUBLIC_ENDPOINT . '?' . courses_build_query( $query );

	return courses_request( $url, courses_cache_key( 'tutor_sso_courses_', $url ) );
}

/**
 * Fetch a page of courses, mapped onto the card shape used by the catalog.
 *
 * `tutor_sso_courses_results` stays available as a short-circuit seam: return an
 * array from it to bypass the API call entirely. `tutor_sso_courses_source`
 * receives the raw API rows (pre-normalization) for the current page.
 *
 * @param int   $page     1-based page number.
 * @param int   $per_page Courses per page.
 * @param array $args     { search, ordering, org (string[]), category (string[]) }.
 * @return array{results:array[],total:int,num_pages:int,error:string}
 */
function courses_fetch( $page = 1, $per_page = 8, $args = array() ) {
	$page     = max( 1, (int) $page );
	$per_page = max( 1, (int) $per_page );

	$empty = array(
		'results'   => array(),
		'total'     => 0,
		'num_pages' => 0,
		'error'     => '',
	);

	// Real-API seam: return an array from this filter to bypass the request.
	$external = apply_filters( 'tutor_sso_courses_results', null, $page, $per_page, $args );
	if ( is_array( $external ) ) {
		return wp_parse_args( $external, $empty );
	}

	// Hidden organizations (see sso_hidden_org_prefixes()) are excluded by
	// turning the `org` filter into an allowlist of visible ones. null means
	// nothing is visible at all, so there is no request worth making.
	$args = courses_restrict_org_args( $args );
	if ( null === $args ) {
		return $empty;
	}

	$response = courses_fetch_public( $page, $per_page, $args );

	if ( is_wp_error( $response ) ) {
		$empty['error'] = $response->get_error_message();
		return $empty;
	}

	$rows  = isset( $response['results'] ) && is_array( $response['results'] ) ? $response['results'] : array();
	$total = isset( $response['count'] ) ? (int) $response['count'] : count( $rows );

	$rows = apply_filters( 'tutor_sso_courses_source', $rows, $args );

	$results = array();

	foreach ( $rows as $row ) {
		if ( is_array( $row ) ) {
			$results[] = courses_normalize_course( $row );
		}
	}

	return array(
		'results'   => $results,
		'total'     => $total,
		'num_pages' => $total > 0 ? (int) ceil( $total / $per_page ) : 0,
		'error'     => '',
	);
}

/**
 * Map a raw API course row onto the flat shape the card renderer consumes.
 *
 * @param array $row Raw course object from the API.
 * @return array
 */
function courses_normalize_course( $row ) {
	$key      = isset( $row['course_key'] ) ? trim( (string) $row['course_key'] ) : '';
	$org_code = isset( $row['org'] ) ? trim( (string) $row['org'] ) : '';
	$org_name = isset( $row['org_arabic_name'] ) ? trim( (string) $row['org_arabic_name'] ) : '';

	$course = array(
		'id'         => $key,
		'key'        => $key,
		'slug'       => isset( $row['slug'] ) ? trim( (string) $row['slug'] ) : '',
		'title'      => isset( $row['title'] ) ? (string) $row['title'] : '',
		'image'      => isset( $row['course_image'] ) ? (string) $row['course_image'] : '',
		'url'        => course_detail_url( $row ),
		'org_slug'   => $org_code,
		'org_name'   => '' !== $org_name ? $org_name : $org_code,
		'instructor' => isset( $row['instructor'] ) ? trim( (string) $row['instructor'] ) : '',
		'start_text' => courses_start_date_text( isset( $row['start'] ) ? $row['start'] : '' ),
		// Same fields, same meaning as the detail page (course_pricing_is_paid(),
		// in course-detail-client.php) — the list endpoint now carries pricing too.
		'paid'       => course_pricing_is_paid( isset( $row['pricing_category'] ) ? $row['pricing_category'] : '' ),
		// Subscription content has no price; the card says so instead.
		'subscription' => sso_is_part_of_subscription( $row ),
		'regular'    => isset( $row['regular_price'] ) ? trim( (string) $row['regular_price'] ) : '',
		'sale'       => isset( $row['sale_price'] ) ? trim( (string) $row['sale_price'] ) : '',
		'discount'   => isset( $row['discount_percentage'] ) ? $row['discount_percentage'] : null,
	);

	return apply_filters( 'tutor_sso_courses_card_data', $course, $row );
}

/**
 * Path segment the course detail pages live under, i.e. /{base}/{slug}/.
 *
 * Filterable so a site using a different permalink base for the `course` post
 * type can point the catalog at it.
 *
 * @return string
 */
function courses_detail_base() {
	return (string) apply_filters( 'tutor_sso_course_detail_base', 'course' );
}

/**
 * Resolve the link for a course card: the local `course` post detail page, built
 * from the API `slug` as {site}/course/{slug}/ (mirrors program_detail_url()).
 *
 * Falls back to the LMS about page only when the row carries no slug, so a course
 * that has not been synced to WordPress yet still links somewhere useful.
 *
 * @param array $row Raw course object from the API.
 * @return string URL, or '' when neither a slug nor a course key is available.
 */
function course_detail_url( $row ) {
	$slug = isset( $row['slug'] ) ? trim( (string) $row['slug'] ) : '';
	$key  = isset( $row['course_key'] ) ? trim( (string) $row['course_key'] ) : '';

	if ( '' !== $slug ) {
		// Normalize to lowercase so detail URLs match the WordPress post_name,
		// which WP lowercases on save (e.g. "…-TS101-2014_t1" -> "…-ts101-2014_t1").
		$base = trim( courses_detail_base(), '/' );
		$path = '/' . ( '' !== $base ? $base . '/' : '' ) . rawurlencode( strtolower( $slug ) ) . '/';
		$url  = home_url( $path );
	} elseif ( '' !== $key ) {
		$lms = courses_lms_base_url();
		$url = '' !== $lms ? $lms . '/courses/' . rawurlencode( $key ) . '/about' : '';
	} else {
		$url = '';
	}

	return (string) apply_filters( 'tutor_sso_course_url', $url, $row );
}

/**
 * Format a course start date, localized (Arabic month names on RTL sites).
 *
 * @param string $start ISO 8601 date from the API.
 * @return string Localized date, or '' when absent / unparseable.
 */
function courses_start_date_text( $start ) {
	$start = trim( (string) $start );

	if ( '' === $start ) {
		return '';
	}

	$ts = strtotime( $start );

	if ( ! $ts ) {
		return '';
	}

	$format = get_option( 'date_format' );

	return date_i18n( $format ? $format : 'j F Y', $ts );
}

/**
 * Fetch the available catalog filter options.
 *
 * @return array|\WP_Error {
 *     @type array[] $organizations [ { id, name, short_name, organization_arabic_name,
 *                                     organization_logo, total_courses }, ... ].
 *     @type array[] $categories    [ { id, name, arabic_name, total_courses }, ... ].
 * } or WP_Error on failure.
 */
function courses_fetch_filters() {
	$base = courses_lms_base_url();

	if ( '' === $base ) {
		return new \WP_Error( 'tutor_sso_no_base', __( 'LMS Base URL is not configured.', 'tutor-sso' ) );
	}

	$url  = $base . COURSES_FILTERS_ENDPOINT;
	$body = courses_request( $url, courses_cache_key( 'tutor_sso_course_filters_', $url ) );

	if ( is_wp_error( $body ) ) {
		return $body;
	}

	return array(
		'organizations' => ( isset( $body['organizations'] ) && is_array( $body['organizations'] ) ) ? $body['organizations'] : array(),
		'categories'    => ( isset( $body['categories'] ) && is_array( $body['categories'] ) ) ? $body['categories'] : array(),
		'pricing'       => ( isset( $body['pricing'] ) && is_array( $body['pricing'] ) ) ? $body['pricing'] : array(),
	);
}

/**
 * Raw filters-API organizations, minus the internal ones (see sso_is_hidden_org()
 * in sso-functions.php — the same rule the programs catalog applies).
 *
 * @return array[]|\WP_Error Visible organization objects, or the fetch error.
 */
function courses_visible_orgs() {
	$filters = courses_fetch_filters();

	if ( is_wp_error( $filters ) ) {
		return $filters;
	}

	$visible = array();

	foreach ( $filters['organizations'] as $org ) {
		if ( is_array( $org ) && ! sso_is_hidden_org( $org ) ) {
			$visible[] = $org;
		}
	}

	return $visible;
}

/**
 * The value the list endpoint's `org` filter matches for an organization (short
 * name, falling back to name — ids are not accepted).
 *
 * @param array $org Organization object from the filters API.
 * @return string
 */
function courses_org_filter_value( $org ) {
	$short = isset( $org['short_name'] ) ? trim( (string) $org['short_name'] ) : '';
	$name  = isset( $org['name'] ) ? trim( (string) $org['name'] ) : '';

	return '' !== $short ? $short : $name;
}

/**
 * Turn the requested `org` filter into an allowlist of visible organizations, so
 * hidden ones are excluded from the results (the API has no "exclude" filter).
 *
 * Passing the allowlist rather than dropping rows afterwards keeps `count` and
 * pagination honest.
 *
 * When the organization list cannot be determined at all — the endpoint errored,
 * or answered without a usable `organizations` array — the args are returned
 * untouched: a catalog that briefly shows an internal organization beats one that
 * renders empty because of an unrelated API change. Returning null (nothing to
 * show) is reserved for a list that was read successfully and left nothing.
 *
 * @param array $args Fetch args { search, ordering, org }.
 * @return array|null Args to query with, or null when nothing is visible.
 */
function courses_restrict_org_args( $args ) {
	$filters = courses_fetch_filters();
	$known   = ( ! is_wp_error( $filters ) && ! empty( $filters['organizations'] ) );

	if ( ! $known ) {
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			error_log( // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
				'[tutor-sso] course organizations unavailable; internal organizations are not being excluded'
			);
		}

		return $args;
	}

	$groups  = sso_org_alias_groups( courses_visible_orgs(), $filters['organizations'] );
	$allowed = array_merge( array(), ...$groups );

	if ( empty( $allowed ) ) {
		return null; // The list was readable and every organization is hidden.
	}

	$requested = isset( $args['org'] ) ? array_filter( array_map( 'trim', array_map( 'strval', (array) $args['org'] ) ) ) : array();

	if ( empty( $requested ) ) {
		$args['org'] = $allowed;

		return $args;
	}

	// Keep only visible requested organizations (case-insensitive), and send
	// every alias of each match.
	$lookup = array();
	foreach ( $groups as $index => $group ) {
		foreach ( $group as $alias ) {
			$lookup[ strtolower( $alias ) ] = $index;
		}
	}

	$keep = array();
	foreach ( $requested as $value ) {
		$key = strtolower( $value );

		if ( ! isset( $lookup[ $key ] ) ) {
			continue;
		}

		foreach ( $groups[ $lookup[ $key ] ] as $alias ) {
			if ( ! in_array( $alias, $keep, true ) ) {
				$keep[] = $alias;
			}
		}
	}

	if ( empty( $keep ) ) {
		return null; // Only hidden organizations were asked for.
	}

	$args['org'] = $keep;

	return $args;
}

/**
 * Organizations for the filter dropdown, from the catalog filters API.
 *
 * Hidden organizations are omitted (see sso_hidden_org_prefixes()). The
 * dropdown value is the organization's short name — the string the list
 * endpoint's `org` filter matches (it does not accept ids). Labels prefer the
 * Arabic name. API order is preserved (alphabetical by name).
 *
 * Filterable so alternative data can be injected without editing this file.
 *
 * @return array<int,array{slug:string,name:string,logo:string,count:int}>
 */
function courses_organizations() {
	$visible = courses_visible_orgs();
	$orgs    = array();

	if ( ! is_wp_error( $visible ) ) {
		foreach ( $visible as $org ) {
			$slug = courses_org_filter_value( $org );

			if ( '' === $slug ) {
				continue;
			}

			$name   = isset( $org['name'] ) ? trim( (string) $org['name'] ) : '';
			$arabic = isset( $org['organization_arabic_name'] ) ? trim( (string) $org['organization_arabic_name'] ) : '';

			$orgs[] = array(
				'slug'  => $slug,
				'name'  => '' !== $arabic ? $arabic : ( '' !== $name ? $name : $slug ),
				'logo'  => isset( $org['organization_logo'] ) ? (string) $org['organization_logo'] : '',
				'count' => isset( $org['total_courses'] ) ? (int) $org['total_courses'] : 0,
			);
		}
	}

	return apply_filters( 'tutor_sso_courses_organizations', $orgs );
}

/**
 * Categories for the filter dropdown, from the catalog filters API.
 *
 * Mirrors courses_organizations(): the option value is the category *name* — the
 * string the list endpoint's `category` param matches — and labels prefer the
 * Arabic name. Sorted by course count descending, then by label, matching the
 * design. Cached with the rest of the filters response (see courses_request()).
 *
 *
 * Filterable so alternative data can be injected without editing this file.
 *
 * @return array<int,array{slug:string,name:string,count:int}>
 */
function courses_categories() {
	$filters    = courses_fetch_filters();
	$categories = array();

	if ( ! is_wp_error( $filters ) ) {
		foreach ( $filters['categories'] as $category ) {
			if ( ! is_array( $category ) ) {
				continue;
			}

			$name = isset( $category['name'] ) ? trim( (string) $category['name'] ) : '';

			if ( '' === $name ) {
				continue;
			}

			// Multi-select filters are sent comma-joined (category=A,B), so a
			// name containing a comma would reach the API as two names and match
			// nothing. Such a category cannot be offered as an option.
			if ( false !== strpos( $name, ',' ) ) {
				if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
					error_log( // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
						sprintf( '[tutor-sso] course category "%s" skipped: the API filter cannot express a comma', $name )
					);
				}

				continue;
			}

			$arabic = isset( $category['arabic_name'] ) ? trim( (string) $category['arabic_name'] ) : '';

			$categories[] = array(
				'slug'  => $name,
				'name'  => '' !== $arabic ? $arabic : $name,
				'count' => isset( $category['total_courses'] ) ? (int) $category['total_courses'] : 0,
			);
		}
	}

	usort(
		$categories,
		function ( $a, $b ) {
			if ( $a['count'] === $b['count'] ) {
				return strnatcasecmp( $a['name'], $b['name'] );
			}

			return $b['count'] - $a['count'];
		}
	);

	return apply_filters( 'tutor_sso_courses_categories', $categories );
}

/**
 * Pricing filter options ('free' | 'paid' | 'program_only'), from the catalog
 * filters API. Labels come from sso_pricing_label(), not the API's own `label`
 * (see that function's docblock for why).
 *
 * @return array<int,array{slug:string,name:string,count:int}>
 */
function courses_pricing_options() {
	$filters = courses_fetch_filters();
	$options = array();

	if ( ! is_wp_error( $filters ) ) {
		foreach ( $filters['pricing'] as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$value = isset( $row['value'] ) ? trim( (string) $row['value'] ) : '';

			if ( '' === $value ) {
				continue;
			}

			$fallback = isset( $row['label'] ) ? trim( (string) $row['label'] ) : $value;

			$options[] = array(
				'slug'  => $value,
				'name'  => sso_pricing_label( $value, $fallback ),
				'count' => isset( $row['total_courses'] ) ? (int) $row['total_courses'] : 0,
			);
		}
	}

	return apply_filters( 'tutor_sso_courses_pricing_options', $options );
}
